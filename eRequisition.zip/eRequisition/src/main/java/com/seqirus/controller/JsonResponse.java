package com.seqirus.controller;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import com.seqirus.model.Product;

public class JsonResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6068468726020402737L;
	
	private String status;
	private List<Product> productLst = new LinkedList<Product>();
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<Product> getProductLst() {
		return productLst;
	}
	public void setProductLst(List<Product> productLst) {
		this.productLst = productLst;
	}
}
