package com.seqirus.controller;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.seqirus.dao.FileHandlerDAOImpl;
import com.seqirus.model.FileUploadValidationVO;
import com.seqirus.model.FileUploadValidator;
import com.seqirus.model.Product;
import com.seqirus.model.ProductValidationResult;
import com.seqirus.model.SupplierDataForm;
import com.seqirus.service.ProductMaintServiceImpl;
import com.seqirus.util.Messages;

/**
 * Handles requests for the application home page.
 */

@Controller
public class HomeController {

	static boolean confirm = false;

	@Autowired
	ProductMaintServiceImpl productMaintServiceImpl;
	@Autowired
	FileHandlerDAOImpl fileHandlerDAOImpl;
	@Autowired
	FileUploadValidator fileuploadvalidator;

	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	private static final int BUFFER_SIZE = 4096;

	@RequestMapping(value = "/*", method = RequestMethod.GET)
	public String welcomeForm() {
		LOGGER.info("invokes welcome screen");
		return "welcome";
	}

	@RequestMapping(value = "welcome", method = RequestMethod.GET)
	public String loginForm() {
		LOGGER.info("coming from itercept security and invokes login screen");
		return "login";
	}

	@RequestMapping(value = "loggedout", method = RequestMethod.GET)
	public String logoutForm() {
		LOGGER.info("invokes logout screen");
		return "logout";
	}

	@RequestMapping(value = "show.html", method = RequestMethod.GET)
	public String displayForm() {
		return "home";
	}

	@RequestMapping(value = "uploadjsp.html", method = RequestMethod.GET)
	public String uploadjsp() {
		LOGGER.info("Dispaly upload form");
		return "UploadForm";
	}

	@RequestMapping(value = "imgupload.html", method = RequestMethod.GET)
	public String ImageUploadForm() {
		LOGGER.info("I am invoking image jsp ");
		return "imgUpload";
	}

	@RequestMapping(value = "suppViewDel.html", method = RequestMethod.GET)
	public String SuppViewAndDeleteForm() {
		LOGGER.info("I am invoking menu for view or del Supplier jsp ");
		return "SupplierViewUpload";
	}

	@RequestMapping(value = "/imageUploadFile", method = RequestMethod.POST)
	public String catalogCreation(@ModelAttribute("supplierDataForm") SupplierDataForm supplierDataForm,
			ServletResponse response, Model map, HttpSession session, BindingResult validation,
			final RedirectAttributes redirectAttributes) throws SQLException, IOException {

		for (CommonsMultipartFile multipartFile : supplierDataForm.getFileUploadImg()) {
			double bytes = multipartFile.getSize();
			double kilobytes = (bytes / 1024);
			double megabytes = (kilobytes / 1024);

			if (megabytes > 2) { // restict for 2MB
				supplierDataForm.setFilesize("Image file size should be less than 2MB");
				map.addAttribute("suppdataformSize", supplierDataForm);
				return "UploadForm";
			}
		}

		/* for image upload */
		List<String> fileNames = new ArrayList<String>();
		for (CommonsMultipartFile multipartFile : supplierDataForm.getFileUploadImg()) {
			String fileName = multipartFile.getOriginalFilename();
			// Get the upload directory real path name
			String filePath = Messages.getMessage("excelPath");
			String imagePath = Messages.getMessage("imagePath");
			StringBuilder fileDest = new StringBuilder();
			fileDest = fileDest.append(filePath);

			if (!multipartFile.getOriginalFilename().equals("")) {
				try {
					String path = session.getServletContext().getRealPath("/");
					multipartFile.transferTo(new File(imagePath + productMaintServiceImpl.appendSupplierIDtoImgName(
							supplierDataForm.getSupplierId(), multipartFile.getOriginalFilename())));
				} catch (IllegalStateException e) {

					LOGGER.error("cause : " + e);

				} catch (IOException e) {

					LOGGER.error("cause : " + e);
				}
				fileNames.add(fileName);

			} // if
		} // for

		/*
		 * for CSV upload &/
		 */
		ModelAndView model = null;
		CommonsMultipartFile csvFile = supplierDataForm.getFileUploadCsv();
		LOGGER.info("csv file name is " + csvFile.getOriginalFilename());
		String fileName = csvFile.getOriginalFilename();
		String fileExtension = fileHandlerDAOImpl.getfileExtension(fileName);
		supplierDataForm.setExtension(fileExtension);
		try {
			if (null != fileExtension && !fileExtension.isEmpty() && !fileExtension.equalsIgnoreCase("csv")) {
				supplierDataForm.setExtension("Uploaded files should be CSV only");

				map.addAttribute("suppdataformext", supplierDataForm);
				return "UploadForm";
			} else {
				supplierDataForm.setExtension("No Files Uploaded");
				model = new ModelAndView("UploadForm");
				model.addObject("suppdataformext", supplierDataForm);
			}

		} catch (Exception e) {
			LOGGER.error("cause : " + e);
		}

		String fileUploadPath = "";
		String filePath = Messages.getMessage("excelPath");
		LOGGER.info("File to uploaded filePath= " + filePath);

		FileUploadValidationVO validVo = new FileUploadValidationVO();

		if (csvFile.getSize() == 0) {

			validVo.setFilecount("0");

		}

		fileuploadvalidator.validate(validVo, validation);
		if (validation.hasErrors()) {
			LOGGER.info("has errors");
			// model.addObject("read");

			supplierDataForm.setErrormsg("No file selected to upload(CSV is mandatory)");

			model = new ModelAndView("UploadForm");

			model.addObject("suppdataform", supplierDataForm);
			redirectAttributes.addAttribute("supplierId", supplierDataForm.getSupplierId());
			redirectAttributes.addFlashAttribute("suppdataform", supplierDataForm);
			redirectAttributes.addAttribute("hasError", true);
			redirectAttributes.addAttribute("validationFlag", "");

		} else {
			LOGGER.info("has no errors");

			model = new ModelAndView("read");

			String supplierName = supplierDataForm.getSupplierName();

			String supplierId = supplierDataForm.getSupplierId();

			if (confirm) {

				fileHandlerDAOImpl.deleteData(supplierId);

			}

			File f = new File(filePath);

			if (f.exists() && f.isDirectory()) {

				LOGGER.info("yes there was existing directory named where  ");
				f.delete();

			}

			StringBuilder fileDest = new StringBuilder();

			if (csvFile != null && (csvFile.getSize() != 0)) {
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath() + File.separator + csvFile.getName() + ".csv");
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(csvFile.getBytes());
				stream.close();

				LOGGER.info("Server File Location=" + serverFile.getAbsolutePath());

				fileDest.append(filePath);

				fileDest.append("//");

				fileDest.append(csvFile.getOriginalFilename());

				DiskFileItem diskItem = (DiskFileItem) csvFile.getFileItem();

				fileUploadPath = diskItem.getName();
				fileUploadPath = serverFile.getAbsolutePath();
				try {

					csvFile.transferTo(new File(fileDest.toString()));

				} catch (IllegalStateException e) {
					LOGGER.error("cause : " + e);
				} catch (IOException e) {
					LOGGER.error("cause : " + e);
				}

			}
			List<ProductValidationResult> productValidationList = null;
			try {

				productValidationList = productMaintServiceImpl.print_csv_text(fileUploadPath, supplierName,

						null != supplierId && !supplierId.isEmpty() ? Integer.valueOf(supplierId) : 0);

			} catch (NumberFormatException e) {

				// TODO Auto-generated catch block

				LOGGER.error("cause : " + e);
			} catch (FileNotFoundException e) {

				// TODO Auto-generated catch block
				LOGGER.error("cause : " + e);
			}

			LOGGER.info("am in CSV upload controller");
			// System.out.println(" am in upload controller");
			Product product = new Product();

			redirectAttributes.addAttribute("supplierId", supplierId);

			if (productValidationList.size() > 0) {
				redirectAttributes.addAttribute("validationFlag", "true");
			} else {
				redirectAttributes.addAttribute("validationFlag", "false");
			}
			redirectAttributes.addAttribute("hasError", false);
		}
		return "redirect:productPage";
	}

	/* For download of log */

	@RequestMapping(value = "/downloadlog", method = RequestMethod.GET)
	public void downloadlog(HttpServletRequest request,

			HttpServletResponse response) throws IOException {

		String filePath = Messages.getMessage("excelPath");

		// get absolute path of the application
		ServletContext context = request.getSession().getServletContext();
		String appPath = context.getRealPath("");
		LOGGER.info("appPath = " + appPath);

		// construct the complete absolute path of the file

		String fullPath = Messages.getMessage("logPath");

		File downloadFile = new File(fullPath);
		FileInputStream inputStream = new FileInputStream(downloadFile);

		// get MIME type of the file
		String mimeType = context.getMimeType(fullPath);
		if (mimeType == null) {
			// set to binary type if MIME mapping not found
			mimeType = "application/octet-stream";
		}
		LOGGER.info("MIME type: " + mimeType);

		// set content attributes for the response
		response.setContentType(mimeType);
		response.setContentLength((int) downloadFile.length());

		// set headers for the response
		String headerKey = "Content-Disposition";
		String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
		response.setHeader(headerKey, headerValue);

		// get output stream of the response
		OutputStream outStream = response.getOutputStream();

		byte[] buffer = new byte[BUFFER_SIZE];
		int bytesRead = -1;

		// write bytes read from the input stream into the output stream
		while ((bytesRead = inputStream.read(buffer)) != -1) {
			outStream.write(buffer, 0, bytesRead);
		}

		inputStream.close();
		outStream.close();

	}

	@RequestMapping(value = "/productPage", method = RequestMethod.GET)
	public ModelAndView finalPage(@RequestParam("supplierId") String supplierId,
			@RequestParam("hasError") boolean hasError, @RequestParam("validationFlag") String validationFlag,
			@ModelAttribute("suppdataform") SupplierDataForm suppdataform, ModelMap modelMap) throws IOException {

		ModelAndView mod = null;
		if (hasError) {
			mod = new ModelAndView("UploadForm");
			modelMap.addAttribute("suppdataform", suppdataform);
		} else {
			mod = new ModelAndView("read");
			Product product = new Product();
			List<Product> list = productMaintServiceImpl
					.getList(null != supplierId && !supplierId.isEmpty() ? Integer.valueOf(supplierId) : 0);
			modelMap.addAttribute("lists", list);
			modelMap.addAttribute("product", product);
			modelMap.addAttribute("validationFlag", validationFlag);
		}

		return mod;
	}

	@RequestMapping(value = "/userSearch", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public void suppliersearch(@RequestParam String userid, ServletResponse response) throws SQLException, IOException {
		{
			List<String> suppList;

			suppList = fileHandlerDAOImpl.search(userid);
			if (suppList.size() > 0) {
				confirm = true;

			} else {
				confirm = false;
			}
			Gson gson = new Gson();
			String gsonData = gson.toJson(suppList);
			LOGGER.info("returning gson " + gsonData);
			response.getOutputStream().write(gsonData.getBytes());

		}
	}

	@RequestMapping(value = "/navBasket", method = RequestMethod.POST)
	@ResponseBody
	public String navBasket(@ModelAttribute("product") Product product) {
		JsonResponse jsonResp = new JsonResponse();
		Gson gson = new Gson();
		String jsonStr = "";
		if (null != product && null != product.getProductLst()) {
			List<Product> productLst = new LinkedList<Product>();
			for (Product product2 : product.getProductLst()) {
				if (product2.isRowSelect()) {
					productLst.add(product2);
				}
			}
			jsonResp.setProductLst(productLst);
			jsonResp.setStatus("SUCCESS");
			jsonStr = gson.toJson(jsonResp);
		}

		return jsonStr;
	}

	@RequestMapping(value = "/save.do", method = RequestMethod.POST)
	public String saveData(Model map, @RequestParam MultipartFile file,
			@ModelAttribute("supplierDataForm") SupplierDataForm supplierDataForm) {

		String orgFileName = file.getOriginalFilename();
		String filePath = Messages.getMessage("excelPath") + orgFileName;

		LOGGER.info("filepath in save data()=" + filePath);
		String supplierName = supplierDataForm.getSupplierName();

		File dest = new File(filePath);
		try {
			file.transferTo(dest);
		} catch (IllegalStateException e) {
			LOGGER.error(" Exception Occured in HomeController on save() " + e);
		} catch (IOException e) {
			LOGGER.error(" Exception Occured in HomeController on save() " + e);
		}

		return "ReadyToParse";

	}

	@RequestMapping(value = "/sapBasket", method = RequestMethod.POST)
	public ModelAndView basket(@ModelAttribute("product") Product product, BindingResult result) {

		List<Product> productLst = new ArrayList<Product>();

		LOGGER.info("Entered into basket controller....");

		ModelAndView model = new ModelAndView("basket");
		if (null != product && null != product.getProductLst()) {
			if (null != product && null != product.getProductLst()) {
				for (Product product2 : product.getProductLst()) {
					if (product2.isRowSelect()) {
						productLst.add(product2);
					}
				}

			}
		}
		model.addObject("lists", productLst);

		// model.addObject("product", product);
		return model;
	}

	@RequestMapping(value = "/supplierSearch.do", method = RequestMethod.POST)
	public ModelAndView supplierSearch(@RequestParam("supplierID") String supplierID, HttpServletRequest request,
			Model map) throws IOException {
		String hookURL = request.getParameter("HOOK_URL");
		request.getSession().setAttribute("HOOK_URL", hookURL);
		request.getSession().setAttribute("HOOK_URL", hookURL);
		ModelAndView model = new ModelAndView("supplierSearch");
		List<Product> productList = null;
		String supplierName = "";
		Product product = new Product();
		if (null != supplierID && !supplierID.isEmpty()) {
			productList = productMaintServiceImpl.getListSupplierSearch(Integer.valueOf(supplierID));
			supplierName = productMaintServiceImpl.getSupplierName(Integer.valueOf(supplierID));
			try {
				for (Product product2 : productList) {
					BufferedImage bImage = ImageIO.read(new File(product2.getImageLink()));// give
																							// the
																							// path
																							// of
																							// an
																							// image
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ImageIO.write(bImage, "gif", baos);
					baos.flush();
					byte[] imageInByte = baos.toByteArray();
					baos.close();

					byte[] encodeBase64 = Base64.encodeBase64(imageInByte);

					String base64DataString = new String(encodeBase64);
					product2.setImageByteStrArr(base64DataString);
				}

			} catch (IIOException imgIO) {
				LOGGER.error("Exception reading message " + imgIO);
			}
		} else {
			productList = new LinkedList<Product>();
		}
		model.addObject("productList", productList);
		model.addObject("product", product);
		model.addObject("supplierName", supplierName);
		return model;
	}

	@RequestMapping(value = "/sapSuppBasket", method = RequestMethod.POST)
	public ModelAndView suppBasket(@ModelAttribute("product") Product product, BindingResult result,
			ServletRequest request) throws IOException {
		request.setCharacterEncoding("UTF-8");
		List<Product> productLst = new ArrayList<Product>();
		String supplierName = "";
		LOGGER.info("Entered into Supplier basket controller....");
		ModelAndView model = new ModelAndView("suppbasket");

		if (null != product && null != product.getProductLst()) {
			if (null != product && null != product.getProductLst()) {
				for (Product product2 : product.getProductLst()) {
					if (product2.isRowSelect()) {
						productLst.add(product2);
					}
				}

			}
		}
		model.addObject("lists", productLst);
		model.addObject("supplierName", supplierName);
		// model.addObject("product", product);
		return model;
	}

	@RequestMapping(value = "/return2sap", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView returnsap(@ModelAttribute("product") Product product, Model model) {
		List<Product> productLst = new ArrayList<Product>();

		ModelAndView model1 = new ModelAndView("home");

		if (null != product && null != product.getProductLst()) {
			if (null != product && null != product.getProductLst()) {
				for (Product product2 : product.getProductLst()) {
					if (product2.isRowSelect()) {
						productLst.add(product2);
					}
				}

			}
		}
		model1.addObject("lists", productLst);
		// model.addAttribute("hi");
		return model1;
	}

	@RequestMapping(value = "suppdel.html", method = RequestMethod.GET)
	public ModelAndView SuppDelete() {
		LOGGER.info("Invoking supplierDel.jsp");
		ModelAndView model = new ModelAndView("supplierDel");
		SupplierDataForm suppList = new SupplierDataForm();

		suppList = fileHandlerDAOImpl.getListSupplier();

		model.addObject("supplierList", suppList.getSupplierLst());
		model.addObject("supplierDataForm", suppList);
		return model;
	}

	@RequestMapping(value = "/delUpdatedSupp", method = RequestMethod.POST)
	public ModelAndView suppDel(@ModelAttribute("supplierDataForm") SupplierDataForm supplierDataForm,
			BindingResult result, ServletRequest request) throws IOException {
		request.setCharacterEncoding("UTF-8");
		List<SupplierDataForm> supplierLst = new ArrayList<SupplierDataForm>();
		String supplierName = "";
		LOGGER.info(" am in Supplier delete update list controller");

		ModelAndView model = new ModelAndView("supplierDel");

		if (null != supplierDataForm && null != supplierDataForm.getSupplierLst()) {
			if (null != supplierDataForm && null != supplierDataForm.getSupplierLst()) {
				for (SupplierDataForm supp : supplierDataForm.getSupplierLst()) {
					if (supp.isRowSelect()) {
						String SuppId = supp.getSupplierId();
						fileHandlerDAOImpl.deleteData(SuppId);

					} else {
						supplierLst.add(supp);
					}
				}

			}
		}
		model.addObject("supplierList", supplierLst);
		model.addObject("supplierDataForm", supplierDataForm);
		return model;
	}
}
