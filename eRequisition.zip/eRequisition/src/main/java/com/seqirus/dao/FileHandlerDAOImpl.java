package com.seqirus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.seqirus.model.Product;
import com.seqirus.model.SupplierDataForm;

@Repository
public class FileHandlerDAOImpl {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileHandlerDAOImpl.class);

	@Autowired
	private DataSource dataSource;

	
	/*public FileHandlerDAOImpl(DataSource dataSource) {
		this.dataSource = dataSource;
	}*/

	/**
	 * @param prodList
	 */
	public void insertData(List<Product> prodList, int  supplierId) {

		/*String sql = "INSERT INTO product (Supplier_Part_ID,Short_Description_EN,Price_Amount,Currency,Price_Base,UOM,Minimum_Quantity,Quantity_Interval,UNSPSC,Kategorie,Manufacturer_Name,Manufacturer_PartID,Lead_Time,Long_Description_EN,CAS_Number,EC_Number,Package_Size,Link_URL,Image_1,Attachment_1,Synonyms_EN,Valid_From,Valid_To,Product_ID,Supplier_Id)"
							+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)"; 
		 */
		String sql = "INSERT INTO product (Supplier_Part_ID,Short_Description_EN,Price_Amount,Currency,Price_Base,UOM,UNSPSC,Kategorie,Vendor_number,Lead_Time,Long_Description_EN,Service,Link_URL,Image_1,Attachment_1,Product_ID,Supplier_Id)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";  

		Integer productIntial = 0;
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			for(Product product : prodList) {
				if(product.isInsertFlag()){
					PreparedStatement ps = conn.prepareStatement(sql);
					ps.setString(1, product.getSupplier_Part_ID());
					ps.setString(2, product.getShort_Description_EN());
					ps.setString(3, product.getPrice_Amount());  
					ps.setString(4, product.getCurrency());
					ps.setString(5, product.getPrice_Base());
					ps.setString(6, product.getUOM());
					ps.setDouble(7, product.getUNSPSC());
					ps.setString(8, product.getKategorie());
					ps.setString(9, product.getVendor_Number());
					ps.setString(10, product.getLead_Time());
					ps.setString(11, product.getLong_Description_EN());
					ps.setString(12, product.getService());
					ps.setString(13, product.getLink_URL());
					ps.setString(14, product.getImage_1());
					ps.setString(15, product.getAttachment_1());
					ps.setInt(16, (null != product.getProduct_ID() && !product.getProduct_ID().isEmpty()) ? Integer.valueOf(product.getProduct_ID()) : productIntial);
					ps.setInt(17, supplierId);
					int count = ps.executeUpdate();
					ps.close();
				}
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}  catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void insertProduct(List<Integer> productIDLst, int supplierId,String supplierName) {

		String sql = "INSERT INTO supplier (Supplier_Id,SupplierName) values (?,?)"; 

		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,supplierId );
			ps.setString(2, supplierName);
			ps.execute();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
				}
			}
		}
	}
	public List<Product> getSupplier(Integer supplierId) {

		List<Product> productList = new LinkedList<Product>();
		Product product = null;

		String sql = "select pd.Supplier_Part_ID,pd.Short_Description_EN,pd.Price_Amount,pd.Currency,pd.Price_Base,pd.UOM,pd.Kategorie,"
				+ "pd.Vendor_number,pd.Lead_Time,Long_Description_EN from supplier sd, product pd where  sd.Supplier_Id=pd.Supplier_Id"
				+ " and sd.Supplier_Id=?";

		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, supplierId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				product = new Product();
				product.setSupplier_Part_ID(rs.getString(1));
				product.setShort_Description_EN(rs.getString(2));
				product.setPrice_Amount(rs.getString(3));
				product.setCurrency(rs.getString(4));
				product.setPrice_Base(rs.getString(5));
				product.setUOM(rs.getString(6));
				product.setKategorie(rs.getString(7));

				product.setVendor_Number(rs.getString(8));
				product.setLead_Time(rs.getString(9));
				product.setLong_Description_EN(rs.getString(10));
				productList.add(product);
			}
		} catch (Exception e) {
			LOGGER.error(" Exception Occured in FileHandlerDAOImpl on getSupplier() ",e);
			//e.printStackTrace();
		}
		return productList;
	}
	
	
	/*modification for images*/	
	public List<Product> getSupplierSearch(Integer supplierId) {

		List<Product> productList = new LinkedList<Product>();
		Product product = null;

		String sql = "select pd.Supplier_Part_ID,pd.Short_Description_EN,pd.Price_Amount,pd.Currency,pd.Price_Base,pd.UOM,pd.Kategorie,"
				+ "pd.Vendor_number,pd.Lead_Time,Long_Description_EN,pd.Link_URL,pd.Image_1 from  product pd where  pd.Supplier_Id=?";

		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, supplierId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				product = new Product();
				product.setSupplier_Part_ID(rs.getString(1));
				product.setShort_Description_EN(rs.getString(2));
				product.setPrice_Amount(rs.getString(3));
				product.setCurrency(rs.getString(4));
				product.setPrice_Base(rs.getString(5));
				product.setUOM(rs.getString(6));
				product.setKategorie(rs.getString(7));
				product.setVendor_Number(rs.getString(8));
				product.setLead_Time(rs.getString(9));
				product.setLong_Description_EN(rs.getString(10));
				product.setLink_URL(rs.getString(11));
				product.setImage_1(rs.getString(12));
				if(null != product.getLink_URL() && null != product.getImage_1()){
					product.setImageLink(product.getLink_URL().concat(product.getImage_1()));
				}
				//product.setService(rs.getString(11));
				productList.add(product);
			}
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error(" Exception Occured in FileHandlerDAOImpl on getSupplierSearch() ",e);
		}
		return productList;
	}


	public boolean verifySupplier(int supplierId, String supplierName) {
		String sql="SELECT COUNT(Supplier_Id) FROM supplier WHERE Supplier_Id = ?";
		Integer countID = 0;
		boolean supplierExist = false;
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1,supplierId);
			ResultSet rs =  ps.executeQuery();
			while (rs.next()) {
				countID = rs.getInt(1);
			}
		} catch (SQLException e) {
			//e.printStackTrace();
			LOGGER.error(" Exception Occured in FileHandlerDAOImpl on verifySupplier() "+e);
		}
		if(countID > 0){
			supplierExist = true;
		}
		return supplierExist;
	} 
	public String getSupplierName(Integer supplierId) {

		String supplierName = "";
		String sql = "select sd.SupplierName from supplier sd where  sd.Supplier_Id=?";
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, supplierId);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				supplierName = rs.getString(1);
			}
		} catch (Exception e) {
			// e.printStackTrace();
			LOGGER.error(" Exception Occured in FileHandlerDAOImpl on getSupplierName() "+e);
		}
		return supplierName;
	}


	public  List<String> search(String supplierId) {
		List<String> suppList=new ArrayList<String>();
		String supplierName = "";
		String sql =  "select sd.SupplierName from supplier sd where  sd.Supplier_Id=?";
		Connection conn = null;

		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(supplierId));
			ResultSet rs=ps.executeQuery();

			while(rs.next()){
				suppList.add(rs.getString("SupplierName"));
			}//while
		}catch (Exception e) {
			e.printStackTrace();
		}


		return suppList;
	}   


	/**
	 * @param prodList
	 */
	public void deleteData(String SupplierId){
		String sql1="delete from product where Supplier_Id="+Integer.parseInt(SupplierId);
		String sql2="delete from supplier where Supplier_Id="+Integer.parseInt(SupplierId);
		Connection con=null;
		Statement stmt=null;

		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(sql1);
			stmt.executeUpdate(sql2);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

	}

	public SupplierDataForm getListSupplier(){
		SupplierDataForm supData =  new SupplierDataForm(); 
		List<SupplierDataForm> list=new ArrayList<SupplierDataForm>();
		Connection con=null;
		Statement stmt=null;

		String sql="select * from supplier";
		try{

			con=dataSource.getConnection();

			stmt = con.createStatement();
			if(stmt.executeQuery(sql)!=null){
				ResultSet rs= stmt.executeQuery(sql);


				while(rs.next()){
					SupplierDataForm newsupp=new SupplierDataForm();
					newsupp.setSupplierId(Integer.toString(rs.getInt("Supplier_Id")));
					newsupp.setSupplierName(rs.getString("SupplierName"));
					list.add(newsupp);

				}
				Collections.sort(list);
				supData.setSupplierLst(list);
			}//if
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
		return supData;

	}
	
	public String getfileExtension(String fileName){
		String fileExtension = null;
		StringTokenizer st = new StringTokenizer(fileName, "."); 
        while(st.hasMoreTokens()) { 
			fileExtension = st.nextToken();
		}
		return fileExtension;
	} 

}
