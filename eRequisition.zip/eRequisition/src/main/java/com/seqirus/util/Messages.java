package com.seqirus.util;

import java.util.Locale;

import org.springframework.context.MessageSource;

/*<!-- it is meant for the excel path in message.properties -->*/
/**
 * Used to laod the resource bundle
 * 
 */
public class Messages {

	private static MessageSource messageSource = null;

	/**
	 * @param messageSource
	 */
	@SuppressWarnings("static-access")
	public Messages(MessageSource messageSource) {
		this.messageSource = messageSource;

	}

	/**
	 * used to return resource property
	 * 
	 * @param key
	 * @return
	 */
	public static String getMessage(String key) {
		return messageSource.getMessage(key, null, "", Locale.US);
	}

}
