package com.seqirus.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seqirus.dao.FileHandlerDAOImpl;
import com.seqirus.model.Product;
import com.seqirus.model.ProductValidationResult;

@Service
public class ProductMaintServiceImpl implements ProductMaintService {
	private static final char DEFAULT_SEPARATOR = ',';
	private static final char DEFAULT_QUOTE = '"';

	@Autowired
	FileHandlerDAOImpl fileHandlerDAOImpl;

	private static final Logger LOGGER = LoggerFactory.getLogger(ProductMaintServiceImpl.class);

	public FileHandlerDAOImpl getFileHandlerDAOImpl() {
		return fileHandlerDAOImpl;
	}

	public void setFileHandlerDAOImpl(FileHandlerDAOImpl fileHandlerDAOImpl) {
		this.fileHandlerDAOImpl = fileHandlerDAOImpl;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cognizant.service.ReadInterface#print_csv_text()
	 */
	@Override
	public List<ProductValidationResult> print_csv_text(String productFilePath, String supplierName, int supplierId)
			throws FileNotFoundException {
		// productFilePath="eRequisition/Sample test low data.csv";
		// productFilePath="http://localhost:8181/eRequisition/test.csv";
		String errMessage = "";
		// File csvFile = new File(productFilePath);
		BufferedReader br = null;
		// String line = "";
		// String csvSplitBy = ",";
		List<ProductValidationResult> productValidationList = new ArrayList<ProductValidationResult>();
		List<Integer> productIDLst = new ArrayList<Integer>();
		List<Product> prod = new ArrayList<Product>();
		// Scanner scanner = new Scanner(new File(productFilePath));
		try {
			Scanner scanner = new Scanner(new File(productFilePath)); // reading
																		// method
																		// changed

			int count = 0;
			while (scanner.hasNext()) {
				List<String> line = parseLine(scanner.nextLine());

				if (line != null && !line.get(0).equals("Supplier_Part_ID")) {
					/* Format.Field. */
					System.out.println("supplier id is line.get(0) with str =" + line.get(0));
					prod.add(new Product(line.get(0), line.get(1), DotValidation(line.get(2)), line.get(3), line.get(4),
							line.get(5), convertDouble(line.get(6)), line.get(7), line.get(8), line.get(9),
							line.get(10), line.get(11), line.get(12),
							appendSupplierIDtoImgName(String.valueOf(supplierId), line.get(13)), line.get(14),
							line.get(15)));

					boolean insertFlag = validateProductObject(prod.get(count), count + 2, productValidationList);
					prod.get(count).setInsertFlag(insertFlag);
					count++;
				}

			} // while
			boolean supplierExist = false;
			supplierExist = fileHandlerDAOImpl.verifySupplier(supplierId, supplierName);
			if (!supplierExist) {
				fileHandlerDAOImpl.insertProduct(productIDLst, supplierId, supplierName);
			}
			fileHandlerDAOImpl.insertData(prod, supplierId);

		} // try
		catch (FileNotFoundException e) {
			// e.printStackTrace();
			LOGGER.error(" Exception Occured in print_csv_text() " + e);
		} catch (NumberFormatException e) {
			// e.printStackTrace();
			LOGGER.error(" Exception Occured in print_csv_text() " + e);
		} finally {
			if (br != null) {
				try {
					br.close();

				} catch (IOException e) {
					// e.printStackTrace();
					LOGGER.error(" Exception Occured in print_csv_text() " + e);
				}
			} // if
		} // finally
		return productValidationList;
	}

	public String DotValidation(String string) {
		if (string.contains(".")) {
			return string;
		}

		return string + ".00";
	}

	public boolean validateProductObject(Product product, int rowNumber,
			List<ProductValidationResult> productValidationList) {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		ProductValidationResult productValidationRes = new ProductValidationResult();
		boolean insertFlag = true;
		Validator validator = factory.getValidator();

		System.out.println(product);
		Set<ConstraintViolation<Product>> constraintViolations = validator.validate(product);
		for (ConstraintViolation<Product> constraintViolation : constraintViolations) {
			productValidationRes.setColumnName(String.valueOf(constraintViolation.getPropertyPath()));
			productValidationRes.setRowNumber(String.valueOf(rowNumber));
			productValidationRes.setIssueDescription(constraintViolation.getMessage());
			if (null != productValidationRes && null != productValidationRes.getColumnName()
					&& !productValidationRes.getColumnName().isEmpty()) {
				LOGGER.error(" Exception Occured in Upload csv validation  on getColumnName() "
						+ productValidationRes.getColumnName());
				LOGGER.error(
						" Exception Occured in Upload csv on getRowNumber() " + productValidationRes.getRowNumber());
				LOGGER.error(" Exception Occured in Upload csv on getIssueDescription() "
						+ productValidationRes.getIssueDescription());
				productValidationList.add(productValidationRes);
				insertFlag = false;
			}
		}
		return insertFlag;
	}

	public String appendSupplierIDtoImgName(String supplierID, String feedImageName) {
		StringBuilder fileName = new StringBuilder();
		fileName.append(supplierID);
		fileName.append("_");
		fileName.append(feedImageName);

		return fileName.toString();
	}

	public static List<String> parseLine(String cvsLine) {
		return parseLine(cvsLine, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators) {
		return parseLine(cvsLine, separators, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators, char customQuote) {// this
																								// is
																								// logic
																								// by
																								// converting
																								// each
																								// line
																								// of
																								// csv
																								// into
																								// char
																								// array

		List<String> result = new ArrayList<String>();

		// if empty, return!
		if (cvsLine == null && cvsLine.isEmpty()) {
			return result;
		}

		if (customQuote == ' ') {
			customQuote = DEFAULT_QUOTE;
		}

		if (separators == ' ') {
			separators = DEFAULT_SEPARATOR;
		}

		StringBuffer curVal = new StringBuffer();
		boolean inQuotes = false;
		boolean startCollectChar = false;
		boolean doubleQuotesInColumn = false;

		char[] chars = cvsLine.toCharArray();
		// System.out.println("chars[0]="+chars[0]);

		for (char ch : chars) {

			if (inQuotes) {
				startCollectChar = true;
				if (ch == customQuote) {
					inQuotes = false;
					doubleQuotesInColumn = false;
				} else {

					// Fixed : allow "" in custom quote enclosed
					if (ch == '\"') {
						if (!doubleQuotesInColumn) {
							curVal.append(ch);
							doubleQuotesInColumn = true;
						}
					} else {
						curVal.append(ch);
					}

				}
			} else {
				if (ch == customQuote) {

					inQuotes = true;

					// Fixed : allow "" in empty quote enclosed
					/*
					 * if (chars[0] != '"' && customQuote == '\"') {
					 * curVal.append('"'); }
					 */

					// double quotes in column will hit this!
					if (startCollectChar) {
						curVal.append('"');
					}

				} else if (ch == separators) {

					result.add(curVal.toString());

					curVal = new StringBuffer();
					startCollectChar = false;

				} else if (ch == '\r') {
					// ignore LF characters
					continue;
				} else if (ch == '\n') {
					// the end, break!
					break;
				} else {
					curVal.append(ch);
				}
			}

		}

		result.add(curVal.toString());

		return result;
	}

	private int convertInt(String Value) {
		int IntValue = 0;
		try {
			if (Value != null && Value.length() > 0) {
				IntValue = Integer.parseInt(Value);
			}
			// System.out.println("IntValue : "+IntValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return IntValue;

	}

	private double convertDouble(String Value) {
		double doubleValue = 0.0;
		try {
			if (Value != null && Value.length() > 0) {
				doubleValue = Double.parseDouble(Value);
			}
			// System.out.println("DoubleValue : "+doubleValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return doubleValue;
	}

	public List<Product> getList(Integer supplierId) { // pulling data from
														// Table
		List<Product> prod = null;
		prod = fileHandlerDAOImpl.getSupplier(supplierId);
		return prod;
	}

	public List<Product> getListSupplierSearch(Integer supplierID) {
		List<Product> prod = null;
		prod = fileHandlerDAOImpl.getSupplierSearch(supplierID);
		return prod;
	}

	public String getSupplierName(Integer supplierId) {
		String supplierName = "";
		supplierName = fileHandlerDAOImpl.getSupplierName(supplierId);
		return supplierName;
	}

}