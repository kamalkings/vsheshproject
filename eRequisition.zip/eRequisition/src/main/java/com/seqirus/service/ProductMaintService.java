package com.seqirus.service;

import java.io.FileNotFoundException;
import java.util.List;

import com.seqirus.model.ProductValidationResult;

public interface ProductMaintService  {
	List<ProductValidationResult> print_csv_text(String productFilePath, String supplierName, int supplierId) throws FileNotFoundException ; 

}
