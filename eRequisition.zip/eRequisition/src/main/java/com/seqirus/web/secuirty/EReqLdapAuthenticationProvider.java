package com.seqirus.web.secuirty;

import java.util.Collection;

import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.authentication.LdapAuthenticator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

public class EReqLdapAuthenticationProvider extends LdapAuthenticationProvider {

	public EReqLdapAuthenticationProvider(LdapAuthenticator authenticator) {
		super(authenticator);
	}

	public EReqLdapAuthenticationProvider(LdapAuthenticator authenticator,
			LdapAuthoritiesPopulator authoritiesPopulator) {
		super(authenticator, authoritiesPopulator);
	}

	@Override
	protected DirContextOperations doAuthentication(UsernamePasswordAuthenticationToken authentication) {
		return super.doAuthentication(authentication);
	}

	@Override
	protected Collection<? extends GrantedAuthority> loadUserAuthorities(DirContextOperations userData, String username,
			String password) {
		Collection<? extends GrantedAuthority> collectionOfAuthorities = super.loadUserAuthorities(userData, username,
				password);
		return collectionOfAuthorities;
	}

}