package com.seqirus.web.secuirty;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;

public class EReqLdapAuthorityPopulator implements LdapAuthoritiesPopulator {

	// this variable needs to be populated from external resource file
	private String devInstanceLdapRDNPattern = "ou=eReq,ou=Service Accounts";

	@Override
	public Collection<? extends GrantedAuthority> getGrantedAuthorities(DirContextOperations dirContextOperations,
			String arg1) {
		ArrayList<GrantedAuthority> listOfGrantedAuthorities = new ArrayList<GrantedAuthority>();

		String fullDn = dirContextOperations.getNameInNamespace();

		if (fullDn.contains(devInstanceLdapRDNPattern)) {
			listOfGrantedAuthorities.add(new SimpleGrantedAuthority("ROLE_READ_WRITE"));
		} else {
			listOfGrantedAuthorities.add(new SimpleGrantedAuthority("ROLE_READ_ONLY"));
		}
		return listOfGrantedAuthorities;
	}

}