package com.seqirus.model;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;



import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Product {
	
	@Size(min = 1, max = 40, message = "Your Supplier_Part_ID must between 1 to 40 characters")
	private String Supplier_Part_ID;
	
	@Size(min = 1, max = 40, message = "Your Short_Description_EN must between 1 to 40 characters")
	private String Short_Description_EN;
	
	@Pattern(regexp ="^\\d{1,11}(\\.\\d{1,3})?$",  message = "Price of an item per price unit must be within 11 digits before the decimal point, 3 after it. Do not use commas for thousands.")
	private String Price_Amount;
	
	@Size(min = 1, max = 5, message = "Your Currency must be between 1 to 5 characters")
	private String Currency;
	
	@Size(min = 1, max = 5, message = "Your Price_Base must be between 1 to 5 characters")
	@Pattern(regexp ="^[1-9]\\d*$", message="Price base should be 1-9,1 to 5 characters")
	private String Price_Base;
	
	@Size(min = 1, max = 3, message = "Your UOM must be between 1 to 3 characters")
	private String UOM;
	
	private double UNSPSC;
	
	@Size(min = 1, max = 10, message = "Your Kategorie must be between 1 to 10 characters")
	private String Kategorie;
	
	@Size(min = 1, max = 10, message = "Your Vendor_Number must be between 1 to 10 characters")
	private String Vendor_Number;
	
	@Size(min = 1, max = 5, message = "Your Lead_Time must be between 1 to 5 characters")
	private String Lead_Time;
	
	private String Long_Description_EN;
	@Pattern(regexp = "\\b(Yes|No)\\b", message="Your Service values must be Yes or No and it is Case-sensitive")
	private String Service;
	private String Link_URL;
	private String Image_1;
	private String Attachment_1;
	private String Product_ID;
	private String quantity;
    private String supplierName;
	private boolean rowSelect = false;
	private List<Product> productLst = new LinkedList<Product>();
	private String imageLink;
	private List<ProductValidationResult> productValidationList = new ArrayList<ProductValidationResult>();
	private boolean insertFlag;
	private String imageByteStrArr;
	public Product(){
		
	}
	
	
	public Product(String supplier_Part_ID, String short_Description_EN,
				String price_Amount, String currency, String price_Base,
				String uOM,double uNSPSC, String kategorie, String vendor_Number,
				String lead_Time,String long_Description_EN,String service, 
				String link_URL, String image_1,String attachment_1,  String productID) {
				

		Supplier_Part_ID = supplier_Part_ID;
		Short_Description_EN = short_Description_EN;
		Price_Amount = price_Amount;
		Currency = currency;
		Price_Base = price_Base;
		UOM = uOM;
		UNSPSC = uNSPSC;
		Kategorie = kategorie;
		Vendor_Number = vendor_Number;
		Lead_Time = lead_Time;
		Long_Description_EN = long_Description_EN;
		Service = service;
		Link_URL = link_URL;
		Image_1 = image_1;
		Attachment_1 = attachment_1;
		Product_ID = productID;		
	}


	public String getSupplier_Part_ID() {
		return Supplier_Part_ID;
	}


	public void setSupplier_Part_ID(String supplier_Part_ID) {
		Supplier_Part_ID = supplier_Part_ID;
	}


	public String getShort_Description_EN() {
		return Short_Description_EN;
	}


	public void setShort_Description_EN(String short_Description_EN) {
		Short_Description_EN = short_Description_EN;
	}

	public String getCurrency() {
		return Currency;
	}


	public void setCurrency(String currency) {
		Currency = currency;
	}


	public String getPrice_Base() {
		return Price_Base;
	}


	public void setPrice_Base(String price_Base) {
		Price_Base = price_Base;
	}


	public String getUOM() {
		return UOM;
	}


	public void setUOM(String uOM) {
		UOM = uOM;
	}


	public double getUNSPSC() {
		return UNSPSC;
	}


	public void setUNSPSC(double uNSPSC) {
		UNSPSC = uNSPSC;
	}


	public String getKategorie() {
		return Kategorie;
	}


	public void setKategorie(String kategorie) {
		Kategorie = kategorie;
	}


	public String getVendor_Number() {
		return Vendor_Number;
	}


	public void setVendor_Number(String vendor_Number) {
		Vendor_Number = vendor_Number;
	}


	public String getLead_Time() {
		return Lead_Time;
	}


	public void setLead_Time(String lead_Time) {
		Lead_Time = lead_Time;
	}


	public String getLong_Description_EN() {
		return Long_Description_EN;
	}


	public void setLong_Description_EN(String long_Description_EN) {
		Long_Description_EN = long_Description_EN;
	}


	public String getService() {
		System.out.println("return service="+Service);
		return Service;
	}


	public void setService(String service) {
		Service = service;
		System.out.println("Setservice="+Service);
	}


	public String getLink_URL() {
		return Link_URL;
	}


	public void setLink_URL(String link_URL) {
		Link_URL = link_URL;
	}


	public String getImage_1() {
		return Image_1;
	}


	public void setImage_1(String image_1) {
		Image_1 = image_1;
	}


	public String getAttachment_1() {
		return Attachment_1;
	}


	public void setAttachment_1(String attachment_1) {
		Attachment_1 = attachment_1;
	}


	public String getProduct_ID() {
		return Product_ID;
	}


	public void setProduct_ID(String product_ID) {
		Product_ID = product_ID;
	}


	public String getQuantity() {
		return quantity;
	}


	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}


	public boolean isRowSelect() {
		return rowSelect;
	}


	public void setRowSelect(boolean rowSelect) {
		this.rowSelect = rowSelect;
	}


	public List<Product> getProductLst() {
		return productLst;
	}


	public void setProductLst(List<Product> productLst) {
		this.productLst = productLst;
	}
	public String getSupplierName() {
        return supplierName;
 }


 public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
 }

 public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public List<ProductValidationResult> getProductValidationList() {
		return productValidationList;
	}

	public void setProductValidationList(
			List<ProductValidationResult> productValidationList) {
		this.productValidationList = productValidationList;
	}

	public boolean isInsertFlag() {
		return insertFlag;
	}

	public void setInsertFlag(boolean insertFlag) {
		this.insertFlag = insertFlag;
	}


	public String getPrice_Amount() {
		return Price_Amount;
	}


	public void setPrice_Amount(String price_Amount) {
		Price_Amount = price_Amount;
	}


	public String getImageByteStrArr() {
		return imageByteStrArr;
	}


	public void setImageByteStrArr(String imageByteStrArr) {
		this.imageByteStrArr = imageByteStrArr;
	}

	

}
