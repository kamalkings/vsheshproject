package com.seqirus.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

public class SupplierDataForm implements Serializable,Comparable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6077283469487485670L;
	
	private String supplierName;
	private String supplierId;
	private String errormsg;
	private String extension;
	private String filesize;
	CommonsMultipartFile[] fileUploadImg;
	CommonsMultipartFile fileUploadCsv;
	private List<SupplierDataForm> supplierLst = new LinkedList<SupplierDataForm>();
	private boolean rowSelect = false;
	
	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}
	public String getErrormsg() {
		return errormsg;
	}

	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	
	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}


	public CommonsMultipartFile[] getFileUploadImg() {
		return fileUploadImg;
	}

	public void setFileUploadImg(CommonsMultipartFile[] fileUploadImg) {
		this.fileUploadImg = fileUploadImg;
	}

	public CommonsMultipartFile getFileUploadCsv() {
		return fileUploadCsv;
	}

	public void setFileUploadCsv(CommonsMultipartFile fileUploadCsv) {
		this.fileUploadCsv = fileUploadCsv;
	}
	
	
	public List<SupplierDataForm> getSupplierLst() {
		return supplierLst;
	}

	public void setSupplierLst(List<SupplierDataForm> supplierLst) { 
		this.supplierLst = supplierLst;
	}

	public boolean isRowSelect() {
		return rowSelect;
	}

	public void setRowSelect(boolean rowSelect) {
		this.rowSelect = rowSelect;
	}

	public String getFilesize() {
		return filesize;
	}

	public void setFilesize(String filesize) {
		this.filesize = filesize;
	}

	@Override
	public int compareTo(Object o) {
		SupplierDataForm suppsort=(SupplierDataForm)o;
		return this.supplierName.compareTo(suppsort.supplierName);
	}

	
	
}
