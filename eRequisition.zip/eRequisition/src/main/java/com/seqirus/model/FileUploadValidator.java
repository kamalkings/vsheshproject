package com.seqirus.model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

/*@Service
public class FileUploadValidator implements Validator {

	@Override
	public boolean supports(Class clazz) {
		// just validate the FileUpload instances
		return FileUploadValidationVO.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		FileUploadValidationVO file = (FileUploadValidationVO) target;

		if (null != file.getFilecount() && file.getFilecount().equals("0") ) {
			errors.rejectValue("errormsg", "required.fileUpload");

		}
	}*/

@Service
public class FileUploadValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// just validate the FileUpload instances
		return FileUploadValidationVO.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "extension", "required.csv");
		FileUploadValidationVO file = (FileUploadValidationVO) target;

		if (null != file.getFilecount() && file.getFilecount().equals("0") ) {
			errors.rejectValue("errormsg", "required.fileUpload");
			//errors.rejectValue("fileUpload", "required.fileUpload");

		}
	}
}