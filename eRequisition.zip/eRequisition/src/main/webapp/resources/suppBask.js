var selectedProductArray = new Array();
function enableBasketRecord(checkElement){
	var checkID = checkElement.id.split("_");
	var table = $('#example').DataTable();
	console.log(checkElement.id);
	if($(checkElement).prop('checked')){
		$('#rowSelect_'+checkID[1]).val(true);
		var rowData = table.row( $(checkElement).parents('tr')  ).data();
		var product = {
					   Supplier_Part_ID: rowData[0], 
					   Short_Description_EN:rowData[1], 
					   Price_Amount:rowData[2], 
					   Currency:rowData[3],
					   Price_Base:rowData[4],
					   UOM:rowData[5],
					   Kategorie:rowData[6],
					   Vendor_Number:rowData[7],
					   Lead_Time:rowData[8],
					   Long_Description_EN:rowData[9],
					   Image_1:rowData[10],
				};
		
		
		selectedProductArray.push(product);
		console.log (JSON.stringify(selectedProductArray[0]));
	}else{
		$('#rowSelect_'+checkID[1]).val(false);	
	}
}

function postProducts(){
	$.ajax({
		url: "setProductList.do",
		type: "POST",
		contentType: "application/json",
		data: JSON.stringify(selectedProductArray[0]),
	    success: function (response) {
	    	if(response = "SUCCESS"){
	    		alert("dopne");
	    	}
	    },
	    failure: function (response) {          
	        $('#result').html(response);
	    }
	}); 
}
